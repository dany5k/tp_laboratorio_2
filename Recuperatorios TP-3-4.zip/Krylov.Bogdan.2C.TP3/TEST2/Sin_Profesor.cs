﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;
using Excepciones;

namespace TEST2
{
    [TestClass]
    public class Sin_Profesor
    {
        [TestMethod]
        public void TestSinProfesor()
        {
            //Testeo si hay profesor para la clase
            Universidad gim = new Universidad();
            try
            {
                gim += Universidad.EClases.Laboratorio;
            }
            catch (SinProfesorException e)
            {
                Console.WriteLine(e.Message);
            } 
        }
    }
}
