﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;
using Excepciones;

namespace TEST1
{
    [TestClass]
    public class Exeptions
    {
        [TestMethod]
        public void TestExeption()
        {
            //Valido a que el indice sea correcto, paso un indice incorrecto (8), pero como está el try catch no se rompe, si quito el try catch-- se rompe
            Universidad gim = new Universidad();
            try
            {
                int jornada = 8; Jornada.Guardar(gim[jornada]); //aproposito pongo 8
                Console.WriteLine("Archivo de Jornada {0} guardado.", jornada);
                Console.WriteLine(Jornada.Leer());
            }
            catch (ArchivosException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
