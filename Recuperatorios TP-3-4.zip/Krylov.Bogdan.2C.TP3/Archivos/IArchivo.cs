﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public interface IArchivo<T> //ese T quiere decir cualquier clase
    {
         bool guardar(string archivo, T datos);

         bool leer(string archivo, out T datos);
        
    }
}
