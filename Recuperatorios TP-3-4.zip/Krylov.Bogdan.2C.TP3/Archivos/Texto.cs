﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        public bool guardar(string archivo, string datos)
        {
            try
            {
                StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + archivo, false);
                sw.WriteLine(datos);
                sw.Close();
                return true; // En caso de éxito retorna true
            }
            catch (Exception e) // En caso de fallo, lanza una Exeption
            {
                throw new ArchivosException(e); //La capturo y tiro otra --> ArchivosException
            }
        }

        public bool leer(string archivo, out string datos)
        {
            try
            {
                StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + archivo);
                datos = sr.ReadToEnd();
                sr.Close();
                return true;  // En caso de éxito retorna true
            }
            catch (Exception e)  // En caso de fallo, lanza ArchivosException
            {
                throw new ArchivosException(e);
            }
        }
    }
}
