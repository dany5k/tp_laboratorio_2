﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        public bool guardar(string archivo, T datos) //La T datos es el objeto a serializar y T es la clase del objeto
        {
            using (StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + archivo)) //archivo es el nombre del archivo que estoy pasando, puede ser de cualquier tipo (txt, xml, etc)
            {
                try
                {
                    XmlSerializer xs = new XmlSerializer(typeof(T)); //Tipo de (en este caso genérico)
                    xs.Serialize(sw, datos);
                    return true; // En caso de éxito retorna true
                }
                catch (Exception e)  // En caso de fallo, lanza ArchivosException
                {
                    throw new ArchivosException(e);
                }

            }
        }

        public bool leer(string archivo, out T datos)
        {
            using (StreamReader sw = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + archivo))
            {
                try
                {
                    XmlSerializer xs = new XmlSerializer(typeof(T)); //Tipo de 
                    datos = (T)xs.Deserialize(sw);
                    return true; // En caso de éxito retorna true
                }
                catch (Exception e) // En caso de fallo, lanza ArchivosException
                {
                    throw new ArchivosException(e);
                }

            }
        }
    }
}
