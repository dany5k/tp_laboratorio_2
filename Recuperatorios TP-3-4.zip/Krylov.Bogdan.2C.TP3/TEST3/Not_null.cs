﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;

namespace TEST3
{
    [TestClass]
    public class Not_null
    {
        [TestMethod]
        //Verifico a que la lista no esté null
        public void ListaCorrecta()
        {
            Universidad gim = new Universidad();
            Assert.IsNotNull(gim.Alumnos);
        }
    }
}
