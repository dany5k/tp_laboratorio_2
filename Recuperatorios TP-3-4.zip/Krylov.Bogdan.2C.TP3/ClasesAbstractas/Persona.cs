﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        private string _apellido;
        private int _dni;
        private ENacionalidad _nacionalidad;
        private string _nombre;

        #region Properties
        public string Apellido
        {
            get
            {
                return this._apellido;
            }
            set
            {
                if(ValidarNombreApellido(value) !="") //Si es diferente del "", se cargará, sinó no hace nada. Yo pondría aquí un mensaje en caso de que no se carge
                {
                    this._apellido = value;
                }
            }
        }
        public int DNI
        {
            get
            {
                return this._dni;
            }
            set
            {
                this._dni = ValidarDNI(Nacionalidad, value);
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this._nacionalidad;
            }
            set
            {
                this._nacionalidad = value;
            }
        }
        public string Nombre
        {
            get
            {
                return this._nombre;
            }
            set
            {
                if (ValidarNombreApellido(value) != "") //Si es diferente del "", se cargará, sinó no hace nada. Yo pondría aquí un mensaje en caso de que no se carge
                {
                    this._nombre = value;
                }
            }
        }
        public string StringToDNI
        {           
            set
            {
                this.DNI = ValidarDNI(Nacionalidad, value);
            }
        }
        #endregion
        #region Methods
        //Constructors
        public Persona()
        {

        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni,ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
            this.DNI = dni; //DNI en formato int
            
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
            this.StringToDNI=dni; //DNI en formato string
            
        }
        //Functions

        public override string ToString() 
        {
            StringBuilder st = new StringBuilder();
            st.AppendLine("NOMBRE COMPLETO: " + this._apellido + ", " + this._nombre);            
            //st.AppendLine(this._dni.ToString());
            st.AppendLine("NACIONALIDAD: "+this._nacionalidad.ToString());

            return st.ToString();
        }

        private string ValidarNombreApellido(string dato)
        {
            char[] cadena = dato.ToCharArray();
            string result = ""; 
            foreach (char c in cadena)
            {
                if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && c!=' ')
                {
                    return result;
                }
            }

            return dato; //Retorna el dato unicamente si es valido
        }

        //Validation Methods
        private int ValidarDNI(ENacionalidad nacionalidad, int dato)
        {
            if (ENacionalidad.Argentino == nacionalidad) //Si es Argentino, entra
            {
                if (dato > 0 && dato < 90000000) // Si además de ser Argentino tiene valido DNI
                {
                    return dato;
                }
                else //Si no, lanzo la exception
                {
                    throw new DniInvalidoException();
                }
            }
            return dato; //Si no es Argentino
            
        }
        private int ValidarDNI(ENacionalidad nacionalidad, string dato)
        {
            int stringToDni, dni=0;
            stringToDni = int.Parse(dato); //Convierto un string en un int
            try
            {
                dni= ValidarDNI(nacionalidad, stringToDni); //Lo que hago es llamar a mi otro método que resolverá esa validación y retornará los datos
            }
            catch (DniInvalidoException e) //Acá cambia un tipo de excepción por otro: recibe DniInvalidoException y arroja NacionalidadInvalidaException
            {

                throw new NacionalidadInvalidaException(e.Message);
            }
            return dni;
        }

        #endregion

        #region Nested Types
        public enum ENacionalidad { Argentino,Extranjero }
        #endregion
    }
}
