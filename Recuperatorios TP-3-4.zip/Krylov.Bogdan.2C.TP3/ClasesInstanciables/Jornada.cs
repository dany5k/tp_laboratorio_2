﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables 
{
    public class Jornada
    {
        private List<Alumno> _alumnos;
        private Universidad.EClases _clase;
        private Profesor _instructor;

        #region Properties
        public List<Alumno> Alumnos
        {
            get
            {
                return this._alumnos;
            }
            set
            {
                this._alumnos = value;
            }
        }
        public Universidad.EClases Clase
        {
            get
            {
                return this._clase;
            }
            set
            {
                this._clase = value;
            }
        }
        public Profesor Instructor
        {
            get
            {
                return this._instructor;
            }
            set
            {
                this._instructor = value;
            }
        }
        #endregion
        #region Metodos
        public static bool Guardar(Jornada jornada)
        {
            Texto txt= new Texto(); //Eso tiene mi metodo de serializar
            return txt.guardar("Jornada.txt", jornada.ToString());
        }
        private Jornada() { this._alumnos = new List<Alumno>(); }
        public Jornada(Universidad.EClases clase, Profesor instructor):this()//Llamo al constructor que inicializa mi lista
        {
            this.Clase = clase;
            this.Instructor = instructor;
        }
        public static string Leer() 
        {
            string str;
            Texto txt = new Texto();
            txt.leer("Jornada.txt", out str);
            return str;
        }
        public override string ToString()
        {
            StringBuilder st = new StringBuilder();
            st.AppendLine("*********************************************");
            st.AppendLine("<<< JORNADA >>>:\n");
            st.AppendLine("CLASE DE: "+this._clase+" POR "+this._instructor.ToString());
            st.AppendLine("ALUMNOS:");
            foreach (Alumno item in this._alumnos)
            {
                st.AppendLine(item.ToString()); //Añado alumnos
            }
            return st.ToString();
        }
        #endregion
        #region Operators
        public static bool operator==(Jornada j, Alumno a)
        {
            foreach (Alumno item in j._alumnos)
            {
                if (item == a)//Buscará el operador de la clase universitario para comparar y en el caso de tener ese alumno en la lista devuelve true
                {
                    return true;
                }
                
            }
            return false; //En el caso de que el alumno no este en la lista, osea que no toma clases asignadas
        }
        public static bool operator !=(Jornada j, Alumno a) { return !(j==a);}
        public static Jornada operator+(Jornada j, Alumno a)
        {
            foreach (Alumno item in j._alumnos)
            {
                if (item == a)
                {
                    throw new AlumnoRepetidoException();
                }

            }
            j._alumnos.Add(a);
            return j;
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        #endregion
    }
}
