﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using System.Xml.Serialization;
using System.IO;
using Archivos;

namespace ClasesInstanciables 
{
    public class Universidad
    {
        private List<Alumno> _alumnos;
        private List<Jornada> _jornada;
        private List<Profesor> _profesores;

        public List<Alumno> Alumnos
        {
            get{return this._alumnos;}
            set
            {
                this._alumnos = value;
            }
        }
        public List<Profesor> Instructores
        {
            get { return this._profesores; }
            set
            {
                this._profesores = value;
            }
        }
        public List<Jornada> Jornadas
        {
            get { return this._jornada; }
            set
            {
                this._jornada = value;
            }
        }
        public Jornada this[int i] //Indexador
        {
            get
            {
                try // Si el índice es correcto no salta ninguna excepción y el get se ejecuta normalmente
                {
                    return this._jornada[i];
                }
                catch (Exception e) // Si el índice está fuera de rango (out of range) salta una excepción 
                {                   // que a su vez se usa para construir una ArchivosException,
                                    // cuyo constructor recibe una innerException, que en este caso es e
                    throw new ArchivosException(e); //Lanzo la Exeption
                }
            }
            set
            {
                try // Si el índice es correcto no salta ninguna excepción y el set se ejecuta normalmente
                {
                    this._jornada[i] = value;// Asigno un valor del indice 
                }
                catch (Exception e) // Si el índice está fuera de rango (out of range) salta una exeptión
                {
                    if (i == this._jornada.Count) //Si el índice es exactamente Count, entonces en vez de reemplazar uno existente se agrega uno nuevo
                    {                             
                        this._jornada.Add(value);
                    }
                    else                           // Si no puede reemplazar ni agregar, entonces arroja
                    {                              // una ArchivosException(e) como en el get{}
                        throw new ArchivosException(e);
                    }

                }
            }
        }

        #region Metodos
        public Universidad()
        {
            this._alumnos = new List<Alumno>();
            this._jornada = new List<Jornada>();
            this._profesores = new List<Profesor>();
        }

        public static bool Guardar(Universidad gim) 
        {
            Xml<Universidad> xm = new Xml<Universidad>(); //Eso tiene mi metodo de serializar
            return xm.guardar("Universidad.xml",gim);
            #region Código que no necesito (Es para darse cuenta de que no se usa)
            //using (StreamWriter sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "universidad.xml"))
            //{
            //    try
            //    {
            //        XmlSerializer xs = new XmlSerializer(typeof(Universidad)); //Tipo de 
            //        xs.Serialize(sw, gim);
            //        return true;
            //    }
            //    catch (Exception)
            //    {
            //        return false;
            //    }

            //} //No necesito, porque hay un metodo
            #endregion
        }

        public static bool Leer(Universidad gim) // Metodo de lectura desde un Archivo
        {
            Xml<Universidad> xm = new Xml<Universidad>(); 
            return xm.leer("Universidad.xml",out gim);
        }

        private static string MostrarDatos(Universidad gim)
        {
            StringBuilder st = new StringBuilder();
            //foreach (Alumno item in gim._alumnos)
            //{
            //    st.AppendLine(item.ToString());
            //}
            foreach (Jornada item in gim._jornada) //Mi Jornada tiene ya los datos de Alumnos y profesores, por eso no necesito cargar otros datos
                //Están de referensia para información adicional
            {
                st.AppendLine(item.ToString());
            }
            //foreach (Profesor item in gim._profesores)
            //{
            //    st.AppendLine(item.ToString());
            //}
            return st.ToString();
        }
        public override string ToString()
        {
            return MostrarDatos(this); 
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        #endregion

        #region Operadores
        public static bool operator==(Universidad g, Alumno a)
        {
            foreach (Alumno item in g._alumnos)
            {
                if(item==a)
                {
                    return true;
                }//Si está en la lista, entonces está inscripto
            }
            return false;
        }
        public static bool operator !=(Universidad g, Alumno a)
        {
            return!(g==a); 
        }
        public static Profesor operator==(Universidad g, EClases clase)
        {
            
            foreach (Profesor item in g._profesores)
            {
                if (item == EClases.Laboratorio)
                {
                    return item;
                }
                if (item == EClases.Legislacion)
                {
                    return item;
                }
                if (item == EClases.Programacion)
                {
                    return item;
                }
                if (item == EClases.SPD)
                {
                    return  item;
                }
            }
          
                throw new SinProfesorException(); //Si el profesor no da ninguna de estas clases, lanzo la exception
                       
        }
        public static Profesor operator !=(Universidad g, EClases clase)
        {
            foreach (Profesor item in g._profesores)
            {
                if (item != EClases.Laboratorio)
                {
                    return item;
                }
                if (item != EClases.Legislacion)
                {
                    return item;
                }
                if (item != EClases.Programacion)
                {
                    return item;
                }
                if (item != EClases.SPD)
                {
                    return item;
                }
            }
            return null;
        }
        public static bool operator==(Universidad g, Profesor i)
        {
            foreach (Profesor item in g._profesores)
            {
                if(item==i)
                {
                    return true;
                }//Si está en la lista, entonces da clases en la Universidad
            }
            return false;
        }
        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g==i);
        }

        public static Universidad operator+(Universidad g, Alumno a)
        {
            foreach (Alumno item in g._alumnos)
            {
                if (item == a)
                {
                    throw new AlumnoRepetidoException();
                }
                                  
            }
            g._alumnos.Add(a); //Si no está el alumno, lo agrego
            return g;
        }
        public static Universidad operator+(Universidad g, EClases clase)
        {
            foreach (Profesor item in g._profesores)
            {
                if(item==clase)
                {
                    Jornada jorn = new Jornada(clase, item); //Agregé profesor y la clase en el constructor
                    foreach (Alumno i in g._alumnos)
                    {
                        if(i==clase)
                        {
                            jorn += i; //Agrego alumnos                            
                        }
                    }
                    g._jornada.Add(jorn); //Agrego jornada a la lista de Jornadas               
                }
            }
            return g;
        }
        public static Universidad operator+(Universidad g, Profesor i)
        {
            foreach (Profesor item in g._profesores)
            {
                if (item == i)
                {
                    return g;
                }

            }
            g._profesores.Add(i); //Si no está el profesor, lo agrego (No confundir con otro método que verifica si hay profesor que da una clase específica)
            return g;
        }
        #endregion

        #region Nested Types
        public enum EClases { Programacion,Laboratorio,Legislacion,SPD}
        #endregion
    }
}
