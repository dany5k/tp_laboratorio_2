﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;//Agrego

namespace ClasesInstanciables
{
    public sealed class Alumno: Universitario
    {
        private Universidad.EClases _claseQueToma;
        private EEstadoCuenta _estadoCuenta;

        public Alumno() { }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma):base(id,nombre,apellido,dni,nacionalidad)
        {
            this._claseQueToma = claseQueToma;
        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoDeCuenta):this(id,nombre,apellido,dni,nacionalidad,claseQueToma)
        {
            this._estadoCuenta = estadoDeCuenta;
        }

        //Methods

        protected override string MostrarDatos()
        {
            StringBuilder st = new StringBuilder();
            st.AppendLine(base.MostrarDatos());
            st.AppendLine("ESTADO DE CUENTA: "+this._estadoCuenta.ToString());
            st.AppendLine(this.ParticiparEnClase()); //Agrego el método que me devuelve las clases que toma

            return st.ToString();
        }

        protected override string ParticiparEnClase()
        {
            return "TOMA CLASES DE " + this._claseQueToma+"\n--------------------"; //Ese método retorna la clase que toma el alumno
        }

        public override string ToString()
        {
            return MostrarDatos(); // Llama al metodo protected MostrarDatos()
        }

        //Operators
        public static bool operator ==(Alumno a, Universidad.EClases clase)
        {
            return a._estadoCuenta != EEstadoCuenta.Deudor && a._claseQueToma == clase; 
                       
        }
        public static bool operator !=(Alumno a, Universidad.EClases clase)
        {
            return a._claseQueToma != clase;
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        #region Nested Types
        public enum EEstadoCuenta { Becado,Deudor,AlDia}
        #endregion
    }
}
