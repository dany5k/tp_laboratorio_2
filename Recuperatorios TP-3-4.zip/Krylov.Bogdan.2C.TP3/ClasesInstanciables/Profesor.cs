﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor:Universitario
    {
        private Queue<Universidad.EClases> _clasesDelDia; //El enunciado está mal, ya que en el dibujo no se muestra exáctamente así, esa clase no tiene un enumerado
        //El enumerado está en la clase Universidad
        private static Random _random;

        public Profesor(){}

        static Profesor() //Al ser un constructor que se ejecuta primero, dará implementación a ese atributo primero
        {
            _random = new Random();
        }
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad):base(id,nombre,apellido,dni,nacionalidad)
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases(); //Llamo al método de _randomClases() que agregará una clase a mi cola "_clasesDelDia"
            this._randomClases(); //Agrego otra clase
        }
        
        //Methods
        private void _randomClases()
        {
            
            int clase=_random.Next((int)Universidad.EClases.Laboratorio,(int)Universidad.EClases.SPD); //Genera un numero entre los valores especificados y lo guardo en una variable, uso la lógica de converción

            switch (clase)//Voy chequeando los numeros y segun eso agrego la clase correspondiente  
            {
                case 0:
                    this._clasesDelDia.Enqueue(Universidad.EClases.Laboratorio);
                    break;
                case 1:
                    this._clasesDelDia.Enqueue(Universidad.EClases.Legislacion);
                    break;
                case 2:
                    this._clasesDelDia.Enqueue(Universidad.EClases.Programacion);
                    break;
                case 3:
                    this._clasesDelDia.Enqueue(Universidad.EClases.SPD);
                    break;
                default:
                    break;
            }
        }

        protected override string MostrarDatos()
        {
            StringBuilder st = new StringBuilder();
            st.AppendLine(base.MostrarDatos());
            st.AppendLine(this.ParticiparEnClase()); //Metodo que retorna dos clases        

            return st.ToString();
        }

        protected override string ParticiparEnClase() //Método que agrega clases
        {
            StringBuilder st = new StringBuilder();
            st.AppendLine("CLASES DEL DIA: ");
            foreach (Universidad.EClases item in this._clasesDelDia)
            {
                st.AppendLine(item.ToString());
            }
            return st.ToString();
        }
        public override string ToString()
        {
            return this.MostrarDatos();
        }
        public static bool operator==(Profesor i, Universidad.EClases clase)
        {
            bool retorno = false;
            foreach (Universidad.EClases item in i._clasesDelDia)
            {
                if(item==clase)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Profesor i, Universidad.EClases clase) { return !(i == clase); }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
