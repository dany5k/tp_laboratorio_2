﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;

namespace TEST4
{
    [TestClass]
    public class Val_num
    {
        [TestMethod]
        public void ValorNumerico()
        {
            //Dni no es un valor numérico, por lo tanto el único método que puede validarlo es el Parce(), si no logra transformarlo, tira un error
            //En ese caso uso un try catch para capturar el error, pero si se quita el try catch, el test da error
            try
            {
                Profesor i2 = new Profesor(2, "Roberto", "Juarez", "+", EntidadesAbstractas.Persona.ENacionalidad.Extranjero);
            }
            catch (Exception)
            {

                Console.WriteLine("Dni no es un valor numérico o no se puede transformarse");
            }
        }
    }
}
